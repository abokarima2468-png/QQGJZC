import { type ReactNode, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowLeft,
  ArrowUpLeft,
  Check,
  ChevronDown,
  Droplets,
  Menu,
  Phone,
  ShieldCheck,
  Sparkles,
  Star,
  ThermometerSun,
  X,
  Wrench,
} from 'lucide-react';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import teamImage from '../attached_assets/generated_images/riyadh-cleaning-team.jpg';

const queryClient = new QueryClient();
const phone = '0540964071';
const whatsappUrl = `https://wa.me/966${phone.slice(1)}`;
const phoneUrl = `tel:${phone}`;

const services = [
  {
    number: '01',
    icon: Droplets,
    title: 'عزل خزانات المياه',
    description: 'عزل داخلي وخارجي يحافظ على نقاء المياه ويمنع التسرب والتلوث.',
    accent: 'teal',
  },
  {
    number: '02',
    icon: ThermometerSun,
    title: 'عزل الأسطح',
    description: 'حلول عزل مائي وحراري مصممة لحرارة الرياض وتحمي المبنى طوال العام.',
    accent: 'gold',
  },
  {
    number: '03',
    icon: Sparkles,
    title: 'تنظيف احترافي',
    description: 'تنظيف خزانات وأسطح بأدوات آمنة وفريق مدرّب يترك المكان كما تحب.',
    accent: 'coral',
  },
];

const testimonials = [
  {
    quote: 'الفريق حضر في الموعد، شرحوا كل خطوة ونظفوا المكان بعد الانتهاء. الخزان الآن نظيف ومطمئن.',
    name: 'سارة العتيبي',
    detail: 'حي النخيل، الرياض',
    initials: 'س ع',
  },
  {
    quote: 'من أول اتصال إلى التسليم وأنا أشعر أني أتعامل مع ناس فاهمة. فرق الحرارة في الدور العلوي واضح.',
    name: 'عبدالله القحطاني',
    detail: 'حي الملقا، الرياض',
    initials: 'ع ق',
  },
  {
    quote: 'طلبنا تنظيف وعزل خزانات العمارة. سرعة ونظافة والتزام، والأهم أنهم أعطونا صور قبل وبعد.',
    name: 'نواف الدوسري',
    detail: 'حي الياسمين، الرياض',
    initials: 'ن د',
  },
];

const faqs = [
  {
    question: 'هل تقدمون معاينة قبل بدء العمل؟',
    answer: 'نعم، نبدأ بفحص المكان وتحديد سبب المشكلة ثم نوضح لك الحل المناسب والتكلفة قبل التنفيذ، بدون مفاجآت.',
  },
  {
    question: 'كم يستغرق عزل الخزان أو السطح؟',
    answer: 'تختلف المدة حسب المساحة وحالة السطح، لكن غالباً ننجز الأعمال المنزلية خلال يوم واحد مع توضيح وقت الجفاف والاستلام.',
  },
  {
    question: 'هل مواد العزل آمنة للاستخدام مع مياه الشرب؟',
    answer: 'نستخدم مواد مخصصة للخزانات ومطابقة للاستخدام مع مياه الشرب، ويجري تنظيف وتجفيف الخزان قبل تسليمه.',
  },
  {
    question: 'هل تخدمون جميع أحياء الرياض؟',
    answer: 'نعم، نغطي أحياء الرياض ونرتب أقرب موعد مناسب لك. أرسل موقعك عبر واتساب وسنعود إليك بسرعة.',
  },
];

function BrandMark() {
  return (
    <div className="brand-lockup" data-testid="brand-lockup">
      <div className="brand-mark" aria-hidden="true">
        <span />
        <span />
      </div>
      <div className="text-right leading-none">
        <div className="brand-title">درع البيت</div>
        <div className="brand-subtitle">عزل وتنظيف بالرياض</div>
      </div>
    </div>
  );
}

function FloatingContacts() {
  return (
    <div className="floating-contacts" dir="ltr">
      <a className="floating-button floating-whatsapp" href={whatsappUrl} aria-label="تواصل معنا عبر واتساب" data-testid="link-floating-whatsapp">
        <span className="floating-pulse" />
        <svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M20.52 3.48A11.84 11.84 0 0 0 12.07 0C5.5 0 .15 5.34.15 11.91c0 2.1.55 4.15 1.6 5.96L.05 24l6.27-1.64a11.88 11.88 0 0 0 5.75 1.46h.01c6.56 0 11.91-5.35 11.91-11.91 0-3.18-1.24-6.16-3.47-8.43Zm-8.45 18.3h-.01a9.86 9.86 0 0 1-5.03-1.38l-.36-.21-3.72.98.99-3.63-.23-.37a9.84 9.84 0 0 1-1.51-5.25C2.2 6.48 6.63 2.04 12.08 2.04c2.64 0 5.12 1.03 6.98 2.9a9.8 9.8 0 0 1 2.89 6.98c0 5.45-4.44 9.86-9.88 9.86Zm5.42-7.38c-.3-.15-1.77-.87-2.05-.97-.28-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.25-.46-2.39-1.48-.88-.78-1.48-1.75-1.65-2.05-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.49s1.07 2.89 1.22 3.09c.15.2 2.11 3.23 5.12 4.52.72.31 1.28.49 1.72.63.72.23 1.38.2 1.89.12.58-.09 1.77-.72 2.02-1.42.25-.7.25-1.3.17-1.42-.07-.13-.27-.2-.57-.35Z" /></svg>
      </a>
      <a className="floating-button floating-call" href={phoneUrl} aria-label="اتصل بنا الآن" data-testid="link-floating-call">
        <Phone size={22} strokeWidth={2.3} />
      </a>
    </div>
  );
}

function SectionIntro({ eyebrow, title, description, light = false }: { eyebrow: string; title: ReactNode; description: string; light?: boolean }) {
  return (
    <div className={`section-intro ${light ? 'section-intro-light' : ''}`}>
      <div className="eyebrow"><span /> {eyebrow}</div>
      <h2>{title}</h2>
      <p>{description}</p>
    </div>
  );
}

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState(0);

  const closeMenu = () => setMenuOpen(false);

  return (
    <main dir="rtl" className="site-shell">
      <FloatingContacts />

      <header className="site-header">
        <div className="site-container header-inner">
          <a href="#home" onClick={closeMenu} className="brand-link" data-testid="link-brand-home">
            <BrandMark />
          </a>
          <nav className={`main-nav ${menuOpen ? 'is-open' : ''}`} aria-label="التنقل الرئيسي">
            <a href="#services" onClick={closeMenu} data-testid="link-nav-services">خدماتنا</a>
            <a href="#why-us" onClick={closeMenu} data-testid="link-nav-why-us">لماذا نحن</a>
            <a href="#steps" onClick={closeMenu} data-testid="link-nav-steps">كيف نعمل</a>
            <a href="#reviews" onClick={closeMenu} data-testid="link-nav-reviews">آراء العملاء</a>
            <a href="#faq" onClick={closeMenu} data-testid="link-nav-faq">الأسئلة الشائعة</a>
          </nav>
          <div className="header-actions">
            <a href={phoneUrl} className="header-phone" data-testid="link-header-phone" dir="ltr">
              <Phone size={16} />
              <span>{phone}</span>
            </a>
            <a href={phoneUrl} className="button button-small" data-testid="link-header-contact">اتصل الآن <ArrowLeft size={16} /></a>
          </div>
          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'إغلاق القائمة' : 'فتح القائمة'} data-testid="button-menu-toggle">
            {menuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </header>

      <section id="home" className="hero-section">
        <div className="hero-orbit hero-orbit-one" />
        <div className="hero-orbit hero-orbit-two" />
        <div className="site-container hero-grid">
          <div className="hero-copy reveal-up">
            <div className="eyebrow hero-eyebrow"><span /> فريق الرياض الذي تثق به</div>
            <h1>خلك مطمّن.<br /><em>بيتك في أيدٍ أمينة.</em></h1>
            <p className="hero-lead">عزل أسطح وخزانات بالرياض، مع تنظيف احترافي يحافظ على بيتك نظيفاً، بارداً، وآمناً طوال العام.</p>
            <div className="hero-actions">
              <a href={phoneUrl} className="button button-primary" data-testid="link-hero-call">
                اتصل الآن <ArrowLeft size={19} />
              </a>
              <a href="#services" className="text-link" data-testid="link-hero-services">
                اكتشف خدماتنا <ArrowUpLeft size={16} />
              </a>
            </div>
            <div className="hero-trust">
              <div className="avatar-stack" aria-hidden="true">
                <span>م</span><span>س</span><span>ن</span><span>+</span>
              </div>
              <div>
                <div className="stars" aria-label="تقييم 4.9 من 5"><Star fill="currentColor" /><Star fill="currentColor" /><Star fill="currentColor" /><Star fill="currentColor" /><Star fill="currentColor" /></div>
                <span>أكثر من ٨٠٠ عميل في الرياض</span>
              </div>
            </div>
          </div>
          <div className="hero-visual reveal-in">
            <div className="hero-image-wrap">
              <img src={teamImage} alt="فريق درع البيت أثناء فحص سطح منزل في الرياض" fetchPriority="high" />
              <div className="hero-image-wash" />
              <div className="hero-badge">
                <ShieldCheck size={22} />
                <div><strong>ضمان جودة</strong><span>نقف خلف شغلنا</span></div>
              </div>
              <div className="hero-location">الرياض <span>•</span> منذ ٢٠١٤</div>
            </div>
            <div className="hero-stamp" aria-hidden="true"><span>نظافة</span><b>تفرق</b><small>DR بيتك</small></div>
          </div>
        </div>
        <div className="scroll-cue"><span>اسحب للأسفل</span><div /></div>
      </section>

      <section className="marquee-strip" aria-label="مميزات الخدمة">
        <div className="marquee-track">
          <span>عزل مائي</span><i /> <span>عزل حراري</span><i /> <span>تنظيف خزانات</span><i /> <span>فريق موثوق</span><i /> <span>مواعيد دقيقة</span><i /> <span>ضمان مكتوب</span><i />
          <span>عزل مائي</span><i /> <span>عزل حراري</span><i /> <span>تنظيف خزانات</span><i /> <span>فريق موثوق</span><i /> <span>مواعيد دقيقة</span><i /> <span>ضمان مكتوب</span><i />
        </div>
      </section>

      <section id="services" className="section services-section">
        <div className="site-container">
          <SectionIntro eyebrow="ماذا نقدم" title={<>حماية تبدأ من فوق…<br />وتوصل لكل زاوية</>} description="حلول عملية لأكثر ما يتعب البيت في أجواء الرياض. ننظف، نعالج، ونعزل — من أول زيارة." />
          <div className="services-grid">
            {services.map((service) => {
              const Icon = service.icon;
              return (
                <article className={`service-card service-${service.accent}`} key={service.number} data-testid={`card-service-${service.number}`}>
                  <div className="service-top"><span className="service-number">{service.number}</span><div className="service-icon"><Icon size={25} /></div></div>
                  <div className="service-content"><h3>{service.title}</h3><p>{service.description}</p></div>
                  <a href={phoneUrl} className="service-link" data-testid={`link-service-${service.number}`}>اطلب الخدمة <ArrowLeft size={16} /></a>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section id="why-us" className="section philosophy-section">
        <div className="site-container philosophy-grid">
          <div className="philosophy-copy">
            <SectionIntro eyebrow="الفرق في التفاصيل" title={<>شغلنا نظيف.<br />وكلامنا أوضح.</>} description="نؤمن أن الخدمة الممتازة ليست طبقة عزل فقط. هي موعد محترم، شرح مفهوم، ومكان يُسلّم لك أنظف مما كان." />
            <div className="feature-list">
              <div className="feature-item"><span><Check size={17} /></span><div><strong>فحص قبل التسعير</strong><p>نحدد المشكلة أولاً، ثم نشاركك الحل المناسب.</p></div></div>
              <div className="feature-item"><span><Check size={17} /></span><div><strong>مواد مختارة بعناية</strong><p>مناسبة لحرارة الرياض واستخدامك اليومي.</p></div></div>
              <div className="feature-item"><span><Check size={17} /></span><div><strong>استلام يرضيك</strong><p>نراجع معك النتيجة ونترك المكان مرتباً.</p></div></div>
            </div>
          </div>
          <div className="quote-card">
            <div className="quote-mark">“</div>
            <p>البيت المحمي<br /><strong>يُحَسّ</strong> قبل أن يُرى.</p>
            <div className="quote-line" />
            <span>فلسفة درع البيت</span>
            <div className="quote-decoration" />
          </div>
        </div>
      </section>

      <section id="steps" className="section steps-section">
        <div className="site-container">
          <SectionIntro eyebrow="بكل بساطة" title={<>من أول رسالة<br />إلى بيت أهدأ</>} description="ثلاث خطوات واضحة، بدون لف ودوران. أنت تعرف ماذا سيحدث ومتى." />
          <div className="steps-row">
            <div className="step-item"><span className="step-number">١</span><div><h3>تواصل معنا</h3><p>اتصل أو أرسل موقعك وصورة للمكان عبر واتساب.</p></div></div>
            <div className="step-connector" />
            <div className="step-item"><span className="step-number">٢</span><div><h3>نعاين ونقترح</h3><p>فريقنا يفحص الحالة ويشرح لك الخيارات والتكلفة.</p></div></div>
            <div className="step-connector" />
            <div className="step-item"><span className="step-number">٣</span><div><h3>ننّفذ ونطمّنك</h3><p>نبدأ في الموعد، ننظف بعدنا، ونسلّمك النتيجة.</p></div></div>
          </div>
          <div className="steps-cta"><span>جاهز تخلي بيتك أهدأ؟</span><a href={whatsappUrl} className="button button-dark" data-testid="link-steps-whatsapp">راسلنا على واتساب <ArrowLeft size={17} /></a></div>
        </div>
      </section>

      <section className="image-break-section">
        <div className="image-break-overlay" />
        <div className="site-container image-break-content">
          <div className="eyebrow eyebrow-light"><span /> فريق يعرف شغله</div>
          <h2>نشتغل كأن البيت<br /><em>بيتنا.</em></h2>
          <p>معدات احترافية، أيدٍ مدرّبة، واهتمام يبان من أول دقيقة.</p>
          <a href={phoneUrl} className="button button-light" data-testid="link-image-call">احجز موعدك <ArrowLeft size={17} /></a>
        </div>
        <div className="image-caption">لقطة من أحد مشاريعنا <span>الرياض، حي حطين</span></div>
      </section>

      <section id="reviews" className="section reviews-section">
        <div className="site-container">
          <div className="reviews-heading">
            <SectionIntro eyebrow="قالوا عنّا" title={<>راحة البال<br />لها صوت.</>} description="نترك المكان أفضل، ويترك عملاؤنا كلمة طيبة." />
            <div className="overall-rating"><strong>٤.٩</strong><div><div className="stars"><Star fill="currentColor" /><Star fill="currentColor" /><Star fill="currentColor" /><Star fill="currentColor" /><Star fill="currentColor" /></div><span>متوسط تقييم العملاء</span></div></div>
          </div>
          <div className="reviews-grid">
            {testimonials.map((review, index) => (
              <article className="review-card" key={review.name} data-testid={`card-review-${index}`}>
                <div className="review-stars"><Star fill="currentColor" /><Star fill="currentColor" /><Star fill="currentColor" /><Star fill="currentColor" /><Star fill="currentColor" /></div>
                <p>“{review.quote}”</p>
                <div className="review-author"><span>{review.initials}</span><div><strong>{review.name}</strong><small>{review.detail}</small></div><ShieldCheck className="review-verified" size={18} /></div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="section faq-section">
        <div className="site-container faq-grid">
          <SectionIntro eyebrow="عندك سؤال؟" title={<>خلّنا نجاوب<br />قبل ما تسأل.</>} description="هذه أكثر الأسئلة التي تصلنا من أهل الرياض. وإن لم تجد ما تبحث عنه، اتصال واحد يكفي." />
          <div className="faq-list">
            {faqs.map((faq, index) => {
              const isOpen = openFaq === index;
              return (
                <button className={`faq-item ${isOpen ? 'is-open' : ''}`} key={faq.question} onClick={() => setOpenFaq(isOpen ? -1 : index)} aria-expanded={isOpen} data-testid={`button-faq-${index}`}>
                  <span className="faq-question"><b>٠{index + 1}</b>{faq.question}</span><ChevronDown size={19} className="faq-chevron" />
                  <span className="faq-answer">{faq.answer}</span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <section className="final-cta-section">
        <div className="site-container final-cta-content">
          <div className="cta-sparkle cta-sparkle-one" /><div className="cta-sparkle cta-sparkle-two" />
          <div className="eyebrow eyebrow-light"><span /> موعدك يبدأ من هنا</div>
          <h2>خلّ بيتك<br /><em>يتنفس براحة.</em></h2>
          <p>اتصل الآن، وخذ أول خطوة نحو بيت أنظف وأحمي.</p>
          <a href={phoneUrl} className="button button-light button-large" data-testid="link-final-call">اتصل الآن <Phone size={18} /></a>
          <a href={whatsappUrl} className="cta-phone" dir="ltr" data-testid="link-final-whatsapp">أو راسلنا واتساب على {phone}</a>
        </div>
      </section>

      <footer className="site-footer">
        <div className="site-container footer-inner">
          <BrandMark />
          <p>عزل وتنظيف يخلّي بيتك أهدأ.</p>
          <div className="footer-links"><a href="#home" data-testid="link-footer-home">الرئيسية</a><a href="#services" data-testid="link-footer-services">خدماتنا</a><a href="#reviews" data-testid="link-footer-reviews">آراء العملاء</a><a href={phoneUrl} data-testid="link-footer-contact">اتصل بنا</a></div>
          <div className="footer-bottom"><span>© ٢٠٢٤ درع البيت. جميع الحقوق محفوظة.</span><span>الرياض، المملكة العربية السعودية</span></div>
        </div>
      </footer>
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;